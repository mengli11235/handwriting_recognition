
# coding: utf-8

# In[57]:


#这个函数没有用到！
def rreplace(self, old, new, *max):
    count = len(self)
    if max and str(max[0]).isdigit():
        count = max[0]
    return new.join(self.rsplit(old, count))
#这是一个逆序输出的函数，我在网上看到的，但我想了一下，因为我们现有的输出已经逆序了
#但是词内顺序又是顺着来的，比如alef，所以不用逆序
#放在这里仅供参考即可
#https://blog.csdn.net/c465869935/article/details/71106967（详解在这里）


# In[89]:


#打开测试文件，我的是Windows系统，在linux上面就不用加r，然后\换成/
f = open(r'C:\Users\think\Desktop\hello.txt')
text = f.read()
text


# In[96]:


#简单的字符串替换
a=text.replace("alef", "א")
b=a.replace("ayin", "ע")
c=b.replace("bet", "ב")
d=c.replace("dalet", "ד")
e=d.replace("gimel","ג")
f=e.replace("he","ה")
g=f.replace("het","ח")
h=g.replace("kaf","כ")
i=h.replace("kaf-final","ך")
j=i.replace("lamed","ל")
k=j.replace("mem","ם")
l=k.replace("mem-medial","מ")
m=l.replace("nun-final","ן")
n=m.replace("nun-medial","נ")
o=n.replace("pe","פ")
p=o.replace("pe-final","ף")
q=p.replace("qof","ק")
r=q.replace("resh","ר")
s=r.replace("samekh","ס")
t=s.replace("shin","ש")
u=t.replace("taw","ת")
v=u.replace("tet","ט")
w=v.replace("tsadi-final","ץ")
x=w.replace("tsadi-medial","צ")
y=x.replace("waw","ו")
z=y.replace("yod","י")
result=y.replace("zayin","ז")
result


# In[98]:


#打开新的文件并输入，注意用utf8格式
fo = open(r'C:\Users\think\Desktop\newhello.txt','w',encoding='utf-8')
fo.write(result)
# 关闭打开的文件
fo.close()

